"""大学生记账平台的 CPM 与 Beta-PERT 蒙特卡洛工期模拟。"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch

ROOT = Path(__file__).resolve().parent
TASKS = [
    ('A','需求分析',[],2,3,5), ('B','系统与数据库设计',['A'],2,4,6),
    ('C','账户与登录',['B'],2,4,7), ('D','收支记账',['B'],3,5,9),
    ('E','分类与预算',['B'],2,4,7), ('F','统计报表',['D','E'],2,4,7),
    ('G','系统集成',['C','F'],2,3,5), ('H','测试与修复',['G'],3,5,9),
    ('I','部署与验收',['H'],1,2,4),
]
N, SEED, DEADLINE = 10000, 2026, 30

def schedule(durations):
    """输入形状为 (模拟次数, 任务数)，按拓扑顺序计算最早完成时间。"""
    finish = np.zeros_like(durations, dtype=float)
    indices = {task[0]: i for i, task in enumerate(TASKS)}
    for i, (key, _, parents, a, m, b) in enumerate(TASKS):
        if not a <= m <= b or a < 0:
            raise ValueError(f'{key}: invalid estimates')
        if any(p not in indices or indices[p] >= i for p in parents):
            raise ValueError(f'{key}: dependencies must be in topological order')
        start = np.max(finish[:, [indices[p] for p in parents]], axis=1) if parents else 0
        finish[:, i] = start + durations[:, i]
    return finish.max(axis=1), finish

def main():
    out = ROOT / 'results'; out.mkdir(exist_ok=True)
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    rng = np.random.default_rng(SEED)
    samples = np.empty((N, len(TASKS)))
    for i, (_, _, _, a, m, b) in enumerate(TASKS):
        if a == b:
            samples[:, i] = a
        else:
            alpha = 1 + 4 * (m-a)/(b-a)
            beta = 1 + 4 * (b-m)/(b-a)
            samples[:, i] = a + (b-a)*rng.beta(alpha, beta, N)
    total, _ = schedule(samples)
    cpm, _ = schedule(np.array([[t[4] for t in TASKS]], dtype=float))
    corr = [float(np.corrcoef(samples[:, i], total)[0, 1]) if np.std(samples[:, i]) else 0.0 for i in range(len(TASKS))]
    result = {'n': N, 'seed': SEED, 'deadline': DEADLINE, 'cpm': float(cpm[0]),
              'mean': float(total.mean()), 'median': float(np.median(total)),
              'p80': float(np.quantile(total,.8)), 'p90': float(np.quantile(total,.9)),
              'on_time_probability': float(np.mean(total <= DEADLINE)),
              'correlations': {t[0]: corr[i] for i,t in enumerate(TASKS)}}
    (out/'summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    np.savetxt(out/'durations.csv', total, delimiter=',', header='project_duration_days', comments='')
    fig, ax = plt.subplots(figsize=(7.2,3.6)); ax.hist(total, bins=45, color='#427f91', edgecolor='white', linewidth=.3)
    ax.axvline(DEADLINE, color='#c1563d', linestyle='--', label=f'截止日期 {DEADLINE} 天')
    ax.axvline(total.mean(), color='#363a40', linestyle=':', label=f'平均 {total.mean():.2f} 天')
    ax.set(xlabel='项目总工期（工作日）', ylabel='模拟次数'); ax.legend(); fig.tight_layout(); fig.savefig(out/'histogram.png',dpi=180); plt.close(fig)
    order = np.argsort(corr); fig, ax = plt.subplots(figsize=(7.2,3.6))
    ax.barh([TASKS[i][0]+' '+TASKS[i][1] for i in order], [corr[i] for i in order], color='#568178')
    ax.set(xlabel='任务工期与项目总工期的 Pearson 相关系数', xlim=(0,1)); fig.tight_layout(); fig.savefig(out/'sensitivity.png',dpi=180); plt.close(fig)
    pos={'A':(0,1),'B':(1,1),'C':(2,2),'D':(2,1),'E':(2,0),'F':(3,.5),'G':(4,1),'H':(5,1),'I':(6,1)}
    fig, ax = plt.subplots(figsize=(9,3.2))
    for key,name,parents,*_ in TASKS:
        x,y=pos[key]
        for p in parents:
            px,py=pos[p]; ax.add_patch(FancyArrowPatch((px+.34,py),(x-.34,y),arrowstyle='->',mutation_scale=12,color='#52636b'))
        ax.text(x,y,key+'\n'+name,ha='center',va='center',fontsize=9,bbox=dict(boxstyle='round,pad=0.38',facecolor='#e9f2f1',edgecolor='#577a78'))
    ax.set_xlim(-.6,6.6); ax.set_ylim(-.6,2.6); ax.axis('off'); fig.tight_layout(); fig.savefig(out/'network.png',dpi=180); plt.close(fig)
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__ == '__main__': main()
