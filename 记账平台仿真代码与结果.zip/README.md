# 大学生记账平台工期风险模拟

本案例数据为教学假设，并非真实项目记录。模型假设并行任务拥有足够资源，任务工期相互独立，工期单位为工作日。

## 运行

需要 Python 3.9 或更高版本。进入本目录后执行：

```bash
python -m pip install numpy matplotlib
python simulation.py
```

Windows 如果 `python` 不可用，可改用 `py`。程序使用随机种子 2026，运行 10000 次，默认截止日期 30 工作日。任务估计与依赖位于 `simulation.py` 顶部，修改后重新运行即可。终端输出统计指标；`results/` 中包含 JSON 结果、总工期样本 CSV 和三张 PNG 图。

运行时需要系统中文字体，例如 Windows 的 Microsoft YaHei，否则图中文字可能显示为方框。不同 numpy 版本可能有微小差异。

## 文件与提交

`simulation.py` 是仿真源代码，`results/` 是运行结果。课程要求在报告中填写可访问的代码地址；请将此文件夹上传至自己的 GitHub 或学校允许的平台，并在报告中补上实际链接和访问方式。不要将本地路径当作公开地址。
